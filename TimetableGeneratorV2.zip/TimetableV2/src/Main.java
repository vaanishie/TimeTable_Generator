/**
 * ============================================================
 *  Main.java  —  Entry Point
 * ============================================================
 *  Run this file to launch the Timetable Generator v2.
 *
 *  The only job of this class is to hand control over to the
 *  UI on Swing's Event Dispatch Thread (EDT).  All UI work
 *  must happen on the EDT to avoid race conditions.
 * ============================================================
 */
public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new UI().show());
    }
}
